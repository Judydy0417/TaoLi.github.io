---
permalink: /
title: "Biography"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

Tao Li is the director of MS Program in Business Analytics and an associate professor of Information Systems & Analytics in the Leavey School of Business at Santa Clara University. He joined the Business School in Fall 2012 as an assistant professor after graduating with his Ph.D. from The University of Texas at Dallas.

Professor Li’s research interests include sharing economy, crowdfunding, strategic sourcing, supply chain coordination, operations-marketing interface, sustainable operations management, and behavioral operations management. His scholarship has appeared in leading academic journals such as Production and Operations Management, Manufacturing & Service Operations Management, European Journal of Operational Research. His scholarship has been supported by the Santa Clara University Research Grant and the Leavey Research Grant. He is the recipient of the Leavey School of Business Extraordinary Research Award multiple times.

Awards
======
ACE (Accelerated Cooperative Education Leadership Program) Outstanding Faculty, 2016,2019
Leavey School of Business Extraordinary Teaching Award 2016-2021



Courses Taught by Professor Li
======
Machine Learning with Python
Data Analytics with Python
Dashboard with Tableau
Prescriptive Analytics
Business Analytics 
Predictive Analytics
Computer Based Decision Models
Operations Management
Analytical Decision Making


Other Roles
======
Production and Operations Management, Senior Editor
Transportation Research Part E, Associate Editor
Management Science, Regular Reviewer
Operations Research, Regular Reviewer
Manufacturing & Service Operations Management, Regular Reviewer


Create content & metadata
------
For site content, there is one markdown file for each type of content, which are stored in directories like _publications, _talks, _posts, _teaching, or _pages. For example, each talk is a markdown file in the [_talks directory](https://github.com/academicpages/academicpages.github.io/tree/master/_talks). At the top of each markdown file is structured data in YAML about the talk, which the theme will parse to do lots of cool stuff. The same structured data about a talk is used to generate the list of talks on the [Talks page](https://academicpages.github.io/talks), each [individual page](https://academicpages.github.io/talks/2012-03-01-talk-1) for specific talks, the talks section for the [CV page](https://academicpages.github.io/cv), and the [map of places you've given a talk](https://academicpages.github.io/talkmap.html) (if you run this [python file](https://github.com/academicpages/academicpages.github.io/blob/master/talkmap.py) or [Jupyter notebook](https://github.com/academicpages/academicpages.github.io/blob/master/talkmap.ipynb), which creates the HTML for the map based on the contents of the _talks directory).


**Cooperate Companies**
![](/images/editing-talk.png)


