---
permalink: /
title: "Publications"
author_profile: true
redirect_from: 
  - _publications/
---

Publications
======
1. Meng Li, Tao Li, Lili Yu. 2024. <a href="http://example.com">Retail Platform Analytics: Practice, Literature, and Future Research.</a> Production and Operations Management. Forthcoming.
2. Jingna Ji, Tao Li*, Lei Yang. 2023. <a href="http://example.com">Pricing and Carbon Emission Reduction </a> Strategies for Vertically
Differentiated Firms under Cap-and-Trade Regulation.” Transportation Research Part E: Logistics
and Transportation Review, 171, 103064.
3. Xi Shan, Tao Li, Suresh P. Sethi. 2022. “A Responsive Pricing Retailer Sourcing from Competing
Suppliers Facing Disruptions.” Manufacturing & Service Operations Management, 24(1), 196-213.
4. Meng Li, Tao Li*. 2022. “AI Automation and Retailer Regret in Supply Chains.” Production and
Operations Management, 31(1), 83-97.
5. Xiaolong Guo, Qian Gao, Tao Li, Yugang Yu. 2022. “A Cash-strapped Creator’s Reward-based Crowdfunding and Spot Sales Strategies.” Naval Research Logistics, 69(8), 1080-1095.
6. Meng Li, Tao Li*. 2018. “Consumer Search, Transshipment, and Bargaining Power in a Supply Chain.”
International Journal of Production Research, 56(10), 3423-3438.
7. Tao Li, Suresh P. Sethi, Jun Zhang. 2017. “Mitigating Supply Uncertainty: The Interplay Between
Diversification and Pricing.” Production and Operations Management, 26(3), 369-388.
The runner-up/honorable mention for 2018 POMS Wickham Skinner Best Paper Award.
8. Tao Li, Suresh P. Sethi. 2017. “A Review of Dynamic Stackelberg Game Models.” Discrete and
Continuous Dynamical Systems - Series B, 22(1), 125-159.
9. Tao Li, Suresh P. Sethi, Xiuli He. 2015. “Dynamic Pricing, Production, and Channel Coordination with
Stochastic Learning.” Production and Operations Management, 24(6), 857-882.
10. Tao Li, Suresh P. Sethi, Jun Zhang. 2014. “Supply Diversification with Isoelastic Demand.” International Journal of Production Economics, 157, 2-6.

Submitted/Working papers
======


Works in progress
======